# Delivery Friction Discoverer

[Value Stream & Metrics](Delivery%20Friction%20Discoverer/Value%20Stream%20&%20Metrics%203c4f37315c4480ae8f87ef871b8964be.md)

[Lead Time vs Cycle Time](Delivery%20Friction%20Discoverer/Lead%20Time%20vs%20Cycle%20Time%203c4f37315c4480d9a990df1cbcd44024.md)

[Team Topologies](Delivery%20Friction%20Discoverer/Team%20Topologies%203c4f37315c4480bca38fc1a6e2e8c358.md)

[Kotter’s 8-step Change Model](Delivery%20Friction%20Discoverer/Kotter%E2%80%99s%208-step%20Change%20Model%203c4f37315c448044aa59f998b3b94e95.md)

[Cognitive Load](Delivery%20Friction%20Discoverer/Cognitive%20Load%203c4f37315c4480a3880edb509fc9a76d.md)

[Shift-Left](Delivery%20Friction%20Discoverer/Shift-Left%203c4f37315c4480e4949bf3bfa146815a.md)

[Theory of Constraints](Delivery%20Friction%20Discoverer/Theory%20of%20Constraints%203c4f37315c448061b742e8faaf6ee19f.md)

[Bounded Context & Context Mapping](Delivery%20Friction%20Discoverer/Bounded%20Context%20&%20Context%20Mapping%203c4f37315c448072a5a0e5f60efb7d0a.md)

[Wardley Mapping](Delivery%20Friction%20Discoverer/Wardley%20Mapping%203c4f37315c4480b096e1e93235f31403.md)

[Blameless Post-mortem](Delivery%20Friction%20Discoverer/Blameless%20Post-mortem%203c4f37315c44808e9055cede0607d8b4.md)

[Feedback Loops](Delivery%20Friction%20Discoverer/Feedback%20Loops%203c4f37315c4480af87ede4c99eb2a962.md)

[Flow State](Delivery%20Friction%20Discoverer/Flow%20State%203c4f37315c4480bf9f77e3ed84ea76ba.md)

[Reverse Conway Maneuver](Delivery%20Friction%20Discoverer/Reverse%20Conway%20Maneuver%203c4f37315c448061bc61fd1ac83195f7.md)

[Boundary Objects](Delivery%20Friction%20Discoverer/Boundary%20Objects%203c4f37315c4480078294e1a0c2509ce2.md)

[Unit Economics of Software](Delivery%20Friction%20Discoverer/Unit%20Economics%20of%20Software%203c4f37315c4480968ae8e133c6c09e08.md)

[Cynefin Framework](Delivery%20Friction%20Discoverer/Cynefin%20Framework%203c4f37315c4480548e1ccb57410768b0.md)

[Norman Door](Delivery%20Friction%20Discoverer/Norman%20Door%203c4f37315c4480359084d7072363faf5.md)

[Developer-as-a-Customer](Delivery%20Friction%20Discoverer/Developer-as-a-Customer%203c4f37315c448090abe5ff2617243bcc.md)

[Adoption Rate & Churn](Delivery%20Friction%20Discoverer/Adoption%20Rate%20&%20Churn%203c4f37315c4480f0a9e0ffa7deac9351.md)

[Canary Deployment](Delivery%20Friction%20Discoverer/Canary%20Deployment%203c4f37315c4480eeafdbc943eec64db2.md)

[MTTR 중심 사고](Delivery%20Friction%20Discoverer/MTTR%20%EC%A4%91%EC%8B%AC%20%EC%82%AC%EA%B3%A0%203c4f37315c4480fdb2a8e08b35fb9a4f.md)

[Interest vs Principal](Delivery%20Friction%20Discoverer/Interest%20vs%20Principal%203c4f37315c44809fa658fcd1110054b5.md)

[Reverse Game Theory & Mechanism Design](Delivery%20Friction%20Discoverer/Reverse%20Game%20Theory%20&%20Mechanism%20Design%203c4f37315c44803ab6fce1332f588f8e.md)

[Epistemology of Software](Delivery%20Friction%20Discoverer/Epistemology%20of%20Software%203c4f37315c44806cb7efcef669b1ece0.md)

[The Art of Invalidation](Delivery%20Friction%20Discoverer/The%20Art%20of%20Invalidation%203c4f37315c4480b5a0f8e53a30a6e9df.md)

[Radical Minimalism](Delivery%20Friction%20Discoverer/Radical%20Minimalism%203c4f37315c44801f8440fdaf29d30094.md)

[Zero-Ops](Delivery%20Friction%20Discoverer/Zero-Ops%203c4f37315c4480b99620f7f4d60783b9.md)

[Meta-Engineering](Delivery%20Friction%20Discoverer/Meta-Engineering%203c4f37315c44808e92b5df4617288fc0.md)

[Industrial Ecology for Software](Delivery%20Friction%20Discoverer/Industrial%20Ecology%20for%20Software%203c4f37315c4480518ac8c4b71bb4d005.md)

[Total Erasure](Delivery%20Friction%20Discoverer/Total%20Erasure%203c4f37315c44800bb29df65ff6ab294c.md)

[Friction as a Signal](Delivery%20Friction%20Discoverer/Friction%20as%20a%20Signal%203c4f37315c4480bf9eeed0d11f3fc9d1.md)

[Returning to the Child Builder](Delivery%20Friction%20Discoverer/Returning%20to%20the%20Child%20Builder%203c4f37315c4480bab0ddfb18c8d27dc7.md)

[Absolute Metrics](Delivery%20Friction%20Discoverer/Absolute%20Metrics%203c5f37315c44809dbf40dd31a1c20690.md)

[Relative Improvement](Delivery%20Friction%20Discoverer/Relative%20Improvement%203c5f37315c4480ab9d7dd5cca95990c5.md)

[Percentile & SLO](Delivery%20Friction%20Discoverer/Percentile%20&%20SLO%203c5f37315c44803d968ef44815dc283a.md)

[Perceived Performance](Delivery%20Friction%20Discoverer/Perceived%20Performance%203c5f37315c4480a6a794fbbc92ade0db.md)

[Definition of Done 기법](Delivery%20Friction%20Discoverer/Definition%20of%20Done%20%EA%B8%B0%EB%B2%95%203c5f37315c4480b6a6bfe77c145cadf5.md)

[FAST Framework](Delivery%20Friction%20Discoverer/FAST%20Framework%203c5f37315c44801dba1ee7888cdd1b48.md)

[PROXY Metrics](Delivery%20Friction%20Discoverer/PROXY%20Metrics%203c5f37315c4480e1965de0351b5a5a02.md)

[3-Point 분류법](Delivery%20Friction%20Discoverer/3-Point%20%EB%B6%84%EB%A5%98%EB%B2%95%203c5f37315c4480cead0ac5847111b016.md)

[6 Thinking hats](Delivery%20Friction%20Discoverer/6%20Thinking%20hats%203cef37315c44800f87e8fa93d4f53c80.md)

[SCAMPER](Delivery%20Friction%20Discoverer/SCAMPER%203cef37315c44805da4e4edb64cd47e61.md)

[Disney Creative Strategy](Delivery%20Friction%20Discoverer/Disney%20Creative%20Strategy%203cef37315c4480749d67e972da5715e1.md)

[ORID Model](Delivery%20Friction%20Discoverer/ORID%20Model%203cef37315c4480f48f70d70844ec90f9.md)

[Pace Layering](Delivery%20Friction%20Discoverer/Pace%20Layering%203cef37315c4480a799c6cea9bec5767b.md)

[System Dynamics & Casual Loop Diagrams](Delivery%20Friction%20Discoverer/System%20Dynamics%20&%20Casual%20Loop%20Diagrams%203cef37315c4480458f6ce76e902ac216.md)

[OODA Loop](Delivery%20Friction%20Discoverer/OODA%20Loop%203cef37315c4480c491bde8d9ea1b2f14.md)

[Option Theory for Architecture](Delivery%20Friction%20Discoverer/Option%20Theory%20for%20Architecture%203cef37315c4480bf89c8f9dd7be3580d.md)

[Anti-fragility](Delivery%20Friction%20Discoverer/Anti-fragility%203cef37315c4480e29a0ae034104a2f84.md)

[Pyramid Principle](Delivery%20Friction%20Discoverer/Pyramid%20Principle%203ebf37315c44800f911fc4d7a1807e57.md)

[SCQA](Delivery%20Friction%20Discoverer/SCQA%203ebf37315c44807493bde0ce6c823d3e.md)

[Issue Tree](Delivery%20Friction%20Discoverer/Issue%20Tree%203ebf37315c44801aae6be3cff7437006.md)

[Hypothesis-Driven Thinking](Delivery%20Friction%20Discoverer/Hypothesis-Driven%20Thinking%203ebf37315c448084b1ebcec1a65f904b.md)

[3C](Delivery%20Friction%20Discoverer/3C%203ebf37315c44803b9bcac6c3cc2ba632.md)

[4P](Delivery%20Friction%20Discoverer/4P%203ebf37315c44803e89eed372d4109e57.md)

[Lean Canvas](Delivery%20Friction%20Discoverer/Lean%20Canvas%203ebf37315c44802b8856ca1cbdf2f8a5.md)

[Value Proposition Canvas](Delivery%20Friction%20Discoverer/Value%20Proposition%20Canvas%203ebf37315c448010bb51d1e46cfb8ec2.md)

[MosCoW 분석](Delivery%20Friction%20Discoverer/MosCoW%20%EB%B6%84%EC%84%9D%203ebf37315c4480a199c0c88ff2b77187.md)

[RICE Scoring](Delivery%20Friction%20Discoverer/RICE%20Scoring%203ebf37315c4480ea8048d3719806484f.md)

[Non-Functional Requirements](Delivery%20Friction%20Discoverer/Non-Functional%20Requirements%203ebf37315c4480c2bb0eefee2ca9233c.md)

[C4 Model](Delivery%20Friction%20Discoverer/C4%20Model%203ebf37315c448078bd5afce6e37c799b.md)

[Word-smithing Trap](Delivery%20Friction%20Discoverer/Word-smithing%20Trap%20406f37315c448009b6bada5e2f891b82.md)

[Fault-finding reviewer](Delivery%20Friction%20Discoverer/Fault-finding%20reviewer%20406f37315c448008a169c44d7b4c84f6.md)

[Minto Pyramid Principle](Delivery%20Friction%20Discoverer/Minto%20Pyramid%20Principle%2040af37315c4480f6bfbbfbe399699931.md)

[Framing Effect](Delivery%20Friction%20Discoverer/Framing%20Effect%2040af37315c4480d3ac54d3ddc2146942.md)

[린 스타트업 & Build-Measure-Learn 루프](Delivery%20Friction%20Discoverer/%EB%A6%B0%20%EC%8A%A4%ED%83%80%ED%8A%B8%EC%97%85%20&%20Build-Measure-Learn%20%EB%A3%A8%ED%94%84%2040af37315c44801a99d1d58e18d44f2b.md)

[Robert Cialdini](Delivery%20Friction%20Discoverer/Robert%20Cialdini%2040af37315c44800da99dfd0011672f9b.md)

[Cynefin 프레임워크](Delivery%20Friction%20Discoverer/Cynefin%20%ED%94%84%EB%A0%88%EC%9E%84%EC%9B%8C%ED%81%AC%2040af37315c4480099979e8f79331d044.md)

[Karl Popper’s Falsifiability](Delivery%20Friction%20Discoverer/Karl%20Popper%E2%80%99s%20Falsifiability%2040af37315c448081816fcf934e903df7.md)

[Bayesian Inference](Delivery%20Friction%20Discoverer/Bayesian%20Inference%2040af37315c44808cb101f4f133fe95c9.md)

[EV](Delivery%20Friction%20Discoverer/EV%2040af37315c4480fdbe41f51ee3a64b2c.md)

[Pre-Moterm Analysis](Delivery%20Friction%20Discoverer/Pre-Moterm%20Analysis%2040af37315c4480f6af6ad5b9c5301282.md)

[Real Options Analysis](Delivery%20Friction%20Discoverer/Real%20Options%20Analysis%2040af37315c4480459b17efc718bf713c.md)

[Sandwich Book Report](Delivery%20Friction%20Discoverer/Sandwich%20Book%20Report%2040af37315c44805b92f4c0608de2ffc8.md)

[Decision Tree](Delivery%20Friction%20Discoverer/Decision%20Tree%2040af37315c4480af97fde3e9c58e0e0a.md)